plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.lindoso.download"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lindoso.download"
        minSdk = 29          // MediaStore.Downloads (sem pedir permissão de armazenamento)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true   // exigido pelo NewPipeExtractor
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += setOf("META-INF/*.kotlin_module", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "DebugProbesKt.bin")
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Extração de YouTube (busca, sugestões, streams, playlists) — sem login e sem API key
    // Confira a versão mais recente em https://jitpack.io/#TeamNewPipe/NewPipeExtractor
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    // Codificador MP3 (LAME nativo) — conversão do áudio do YouTube para MP3
    implementation("com.github.naman14:TAndroidLame:1.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.2")   // versão NIO: obrigatória para o NewPipeExtractor (URLDecoder etc.)
}
