package com.lindoso.download

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class VideoItem(val url: String, val title: String, val channel: String, val thumb: String?, val seconds: Long)

/** Tudo que fala com o YouTube. Só YouTube, sem login, sem API key. */
object YtRepo {
    private val yt get() = ServiceList.YouTube
    private val ytRegex = Regex("""(https?://)?((www|m|music)\.)?(youtube\.com/(watch\?\S*?v=|shorts/|live/|embed/|playlist\?\S*?list=)|youtu\.be/)[\w-]{10,}\S*""", RegexOption.IGNORE_CASE)
    private val listRegex = Regex("""[?&]list=([\w-]+)""")

    fun init() = NewPipe.init(HttpDownloader(), Localization("pt", "BR"))

    fun isYt(s: String) = ytRegex.containsMatchIn(s.trim())
    fun extract(s: String): String = ytRegex.find(s.trim())!!.value.trimEnd('"', '\'', ')', '.', ',', ';').let { if (it.startsWith("http")) it else "https://$it" }
    fun hasList(url: String) = listRegex.containsMatchIn(url)
    fun playlistUrl(url: String) = "https://www.youtube.com/playlist?list=" + listRegex.find(url)!!.groupValues[1]

    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        runCatching { yt.suggestionExtractor.suggestionList(q).take(6) }.getOrDefault(emptyList())
    }

    suspend fun search(q: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val h = yt.searchQHFactory.fromQuery(q, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        SearchInfo.getInfo(yt, h).relatedItems.filterIsInstance<StreamInfoItem>().map(::toItem)
    }

    suspend fun playlist(url: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val info = PlaylistInfo.getInfo(yt, url)
        val out = info.relatedItems.toMutableList()
        var page = info.nextPage
        while (page != null && out.size < 300) {
            val more = PlaylistInfo.getMoreItems(yt, url, page)
            out += more.items
            page = more.nextPage
        }
        out.map(::toItem)
    }

    private fun toItem(i: StreamInfoItem) =
        VideoItem(i.url, i.name, i.uploaderName ?: "", i.thumbnails.firstOrNull()?.url, i.duration)
}
