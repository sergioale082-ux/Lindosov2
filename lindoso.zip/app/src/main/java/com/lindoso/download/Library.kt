package com.lindoso.download

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

data class LFile(val uri: Uri, val name: String, val size: Long, val mime: String) {
    val isAudio get() = mime.startsWith("audio")
}

/** Pasta pública Download/Lindoso Download/ via MediaStore (Android 10+ não exige permissão de armazenamento). */
object Library {
    private const val REL = "Download/Lindoso Download/"
    private val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI

    fun save(ctx: Context, src: File, name: String, mime: String) {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, REL)
        }
        val uri = ctx.contentResolver.insert(base, cv) ?: error("não foi possível salvar")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
    }

    fun list(ctx: Context): List<LFile> {
        val out = mutableListOf<LFile>()
        val cols = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE, MediaStore.Downloads.MIME_TYPE)
        ctx.contentResolver.query(base, cols, "${MediaStore.Downloads.RELATIVE_PATH} = ?", arrayOf(REL), "${MediaStore.Downloads.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) out += LFile(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1), c.getLong(2), c.getString(3) ?: "")
        }
        return out
    }

    fun rename(ctx: Context, f: LFile, newName: String) =
        ctx.contentResolver.update(f.uri, ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, newName) }, null, null)

    fun delete(ctx: Context, f: LFile) = ctx.contentResolver.delete(f.uri, null, null)

    /** Mover para outro local (cartão SD, outra pasta): o usuário escolhe o destino no seletor do sistema. */
    fun moveTo(ctx: Context, f: LFile, dest: Uri) {
        ctx.contentResolver.openInputStream(f.uri)!!.use { i -> ctx.contentResolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
        delete(ctx, f)
    }
}
