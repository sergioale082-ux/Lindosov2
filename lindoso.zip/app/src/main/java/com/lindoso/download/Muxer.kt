package com.lindoso.download

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/** Junta vídeo (H.264) + áudio (AAC) em um MP4 usando só APIs nativas do Android (zero KB extra no APK). */
object Muxer {
    fun mux(video: File, audio: File, out: File) {
        val m = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val ve = MediaExtractor().apply { setDataSource(video.path) }
        val ae = MediaExtractor().apply { setDataSource(audio.path) }
        try {
            val vt = track(ve, "video/"); val at = track(ae, "audio/")
            ve.selectTrack(vt); ae.selectTrack(at)
            val vi = m.addTrack(ve.getTrackFormat(vt)); val ai = m.addTrack(ae.getTrackFormat(at))
            m.start()
            copy(ve, m, vi); copy(ae, m, ai)
            m.stop()
        } finally { ve.release(); ae.release(); m.release() }
    }

    private fun track(e: MediaExtractor, prefix: String): Int =
        (0 until e.trackCount).first { e.getTrackFormat(it).getString("mime")!!.startsWith(prefix) }

    private fun copy(e: MediaExtractor, m: MediaMuxer, idx: Int) {
        val buf = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        while (true) {
            val n = e.readSampleData(buf, 0)
            if (n < 0) break
            info.set(0, n, e.sampleTime, if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            m.writeSampleData(idx, buf, info)
            e.advance()
        }
    }
}
