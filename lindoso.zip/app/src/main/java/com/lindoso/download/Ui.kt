package com.lindoso.download

import android.content.ClipData
import kotlinx.coroutines.CancellationException
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyRow
import android.webkit.WebChromeClient
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.MediaController
import androidx.activity.compose.BackHandler
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

val Turq = Color(0xFF00E5C7)

@Composable
fun LindosoTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Turq, onPrimary = Color.Black, background = Color.Black, onBackground = Color.White,
        surface = Color.Black, onSurface = Color.White, surfaceVariant = Color(0xFF111111),
        onSurfaceVariant = Color(0xFFB0B0B0), secondaryContainer = Color(0xFF0F2B28), onSecondaryContainer = Turq
    ), content = content
)

/** Aviso de direitos autorais na primeira abertura. */
@Composable
fun CopyrightNotice(onExit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var show by remember { mutableStateOf(!prefs.getBoolean("ok", false)) }
    if (!show) return
    AlertDialog(
        onDismissRequest = {}, containerColor = Color(0xFF111111),
        title = { Text("Aviso de direitos autorais") },
        text = {
            Text(
                "O Lindoso Download deve ser usado apenas para baixar conteúdos seus, com licença livre " +
                    "(Creative Commons) ou com autorização expressa do autor. Baixar conteúdo protegido sem permissão " +
                    "pode violar leis de direitos autorais e os Termos de Serviço do YouTube. A responsabilidade pelo uso é sua."
            )
        },
        confirmButton = { TextButton({ prefs.edit().putBoolean("ok", true).apply(); show = false }) { Text("Entendi e aceito", color = Turq) } },
        dismissButton = { TextButton(onExit) { Text("Sair", color = Color.Gray) } }
    )
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = tab != 0) { tab = 0 }
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color.Black) {
                val items = listOf("Início" to Icons.Default.Home, "Pesquisar" to Icons.Default.Search, "Biblioteca" to Icons.AutoMirrored.Filled.List)
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, label) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.Black, indicatorColor = Turq, selectedTextColor = Turq)
                    )
                }
            }
        }
    ) { p ->
        Box(Modifier.padding(p).fillMaxSize()) {
            HomeTab(active = tab == 0)
            if (tab != 0) Box(
                Modifier.fillMaxSize().background(Color.Black)
                    .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) {}
            ) { if (tab == 1) SearchTab() else LibraryTab() }
        }
    }
}

fun isVideoUrl(u: String) = YtRepo.isYt(u) &&
    (u.contains("watch?v=") || u.contains("/shorts/") || u.contains("youtu.be/") || u.contains("list="))

/** WebView que continua tocando com o app minimizado ou a tela apagada. */
class BgWebView(c: Context) : WebView(c) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE)
    }
}

private const val BG_JS = """(function(){
if(window.__lindosoBg)return;window.__lindosoBg=true;
try{
Object.defineProperty(document,'hidden',{get:function(){return false},configurable:true});
Object.defineProperty(document,'webkitHidden',{get:function(){return false},configurable:true});
Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'},configurable:true});
Object.defineProperty(document,'webkitVisibilityState',{get:function(){return 'visible'},configurable:true});
}catch(e){}
['visibilitychange','webkitvisibilitychange','pagehide','blur'].forEach(function(n){
window.addEventListener(n,function(e){e.stopImmediatePropagation()},true);
document.addEventListener(n,function(e){e.stopImmediatePropagation()},true);
});
})();"""

/** WebView do YouTube mantido vivo entre as abas (não recarrega ao trocar de aba). */
object Web {
    var view: WebView? = null
    var custom by mutableStateOf<View?>(null)          // vídeo em tela cheia
    private var cb: WebChromeClient.CustomViewCallback? = null

    fun exitFullscreen() { cb?.onCustomViewHidden(); cb = null; custom = null }

    fun get(c: Context, onUrl: (String) -> Unit): WebView {
        val w = view ?: BgWebView(c).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(android.graphics.Color.BLACK)
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(v: View, callback: CustomViewCallback) { cb = callback; custom = v }
                override fun onHideCustomView() { cb = null; custom = null }
            }
            loadUrl("https://m.youtube.com")
        }.also { view = it }
        (w.parent as? ViewGroup)?.removeView(w)
        w.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(v: WebView, url: String, isReload: Boolean) { onUrl(url) }
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { v.evaluateJavascript(BG_JS, null) }
            override fun onPageFinished(v: WebView, url: String?) { v.evaluateJavascript(BG_JS, null) }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = r.url.scheme?.startsWith("http") != true
        }
        return w
    }
}

// ───────────────────────── Início ─────────────────────────
@Composable
fun HomeTab(active: Boolean = true) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var webUrl by remember { mutableStateOf(Web.view?.url ?: "") }
    val jobs by Dl.jobs.collectAsState()
    val panel by Dl.panel.collectAsState()
    val fs = Web.custom

    // Voltar: sai da tela cheia → fecha a aba de downloads → volta no YouTube → fecha o app
    BackHandler(enabled = active) {
        val w = Web.view
        when {
            Web.custom != null -> { Web.exitFullscreen() }
            jobs.isNotEmpty() && panel -> { Dl.panel.value = false }
            w != null && w.canGoBack() -> { w.goBack() }
            else -> { (ctx as? Activity)?.finish() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // YouTube ocupa todo o resto da tela
            AndroidView({ c -> Web.get(c) { webUrl = it } }, Modifier.weight(1f).fillMaxWidth())
        }

        // Botão e aba de downloads flutuam por cima do YouTube (não diminuem o player)
        Column(Modifier.align(Alignment.BottomCenter)) {
            if (isVideoUrl(webUrl) && fs == null) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
                    Button(
                        {
                            val t = Web.view?.title?.removeSuffix(" - YouTube")?.takeIf { it.isNotBlank() } ?: webUrl
                            dialog = webUrl to t
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Turq, contentColor = Color.Black)
                    ) { Text("Baixar") }
                }
            }
            if (jobs.isNotEmpty() && panel && fs == null) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .background(Color(0xF2111111)).padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Downloads", color = Turq, modifier = Modifier.weight(1f))
                        TextButton({ Dl.clearFinished() }) { Text("Limpar", color = Color.Gray) }
                        TextButton({ Dl.panel.value = false }) { Text("✕", color = Color.Gray) }
                    }
                    LazyColumn(Modifier.heightIn(max = 170.dp)) { items(jobs.reversed(), key = { it.id }) { JobRow(it) } }
                }
            }
        }

        // Vídeo em tela cheia
        if (fs != null) {
            AndroidView({ (fs.parent as? ViewGroup)?.removeView(fs); fs }, Modifier.fillMaxSize().background(Color.Black))
        }
    }
    dialog?.let { (u, t) -> FormatDialog(u, t) { dialog = null } }
}

@Composable
fun JobRow(j: DlState) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(j.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
        LinearProgressIndicator(progress = { j.progress }, Modifier.fillMaxWidth().padding(vertical = 4.dp), color = Turq, trackColor = Color(0xFF222222))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (j.st) {
                    St.QUEUED -> "Na fila"; St.RUNNING -> if (j.msg.isNotEmpty()) j.msg else "${(j.progress * 100).toInt()}%"; St.PAUSED -> "Pausado"
                    St.WAITING -> j.msg; St.DONE -> "Concluído ✓"; St.ERROR -> "Erro: ${j.msg}"
                }, color = Color.Gray, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall
            )
            when (j.st) {
                St.RUNNING, St.WAITING, St.QUEUED -> TextButton({ Dl.pause(j.id) }) { Text("Pausar", color = Turq) }
                St.PAUSED, St.ERROR -> TextButton({ Dl.resume(j.id) }) { Text("Retomar", color = Turq) }
                else -> {}
            }
        }
    }
}

// ───────────────────────── Escolha de formato ─────────────────────────
@Composable
private fun PickRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Turq, unselectedColor = Color.Gray))
    }
}

/** Seletor estilo Snaptube: Música (MP3/M4A) / Vídeo / Mais formatos + botão Baixar.
 *  sel > 0 = altura do vídeo; sel <= 0 = áudio, onde -sel é o bitrate do MP3 (0 = M4A original, sem conversão). */
@Composable
fun FormatPicker(title: String, hasList: Boolean, busy: Boolean, onGo: (height: Int?, kbps: Int, whole: Boolean) -> Unit) {
    var sel by remember { mutableIntStateOf(0) }
    var more by remember { mutableStateOf(false) }
    var whole by remember { mutableStateOf(false) }
    Column(Modifier.heightIn(max = 560.dp)) {
        Text("Baixar como", style = MaterialTheme.typography.titleLarge)
        Text(title, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            Text("Música", color = Color.Gray)
            PickRow("M4A (áudio original, sem conversão)", sel == 0) { sel = 0 }
            Spacer(Modifier.height(8.dp))
            Text("Vídeo", color = Color.Gray)
            PickRow("Rápido (360p)", sel == 360) { sel = 360 }
            PickRow("Alta qualidade (720p)", sel == 720) { sel = 720 }
            Row(Modifier.fillMaxWidth().clickable { more = !more }.padding(vertical = 10.dp)) {
                Text("Mais formatos", Modifier.weight(1f))
                Text(if (more) "▲" else "Todos ›", color = Color.Gray)
            }
            if (more) {
                PickRow("144p (menor)", sel == 144) { sel = 144 }
                PickRow("1080p (Full HD)", sel == 1080) { sel = 1080 }
            }
            if (hasList) Row(Modifier.clickable { whole = !whole }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(whole, { whole = it }, colors = CheckboxDefaults.colors(checkedColor = Turq, checkmarkColor = Color.Black))
                Text("Baixar playlist inteira")
            }
        }
        Spacer(Modifier.height(8.dp))
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Turq)
        else Button(
            { if (sel > 0) onGo(sel, 0, whole) else onGo(null, -sel, whole) }, Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Turq, contentColor = Color.Black)
        ) { Text("Baixar") }
    }
}

suspend fun startDownload(url: String, title: String, whole: Boolean, height: Int?, kbps: Int) {
    val items = if (whole) runCatching { YtRepo.playlist(YtRepo.playlistUrl(url)).map { it.url to it.title } }.getOrDefault(emptyList())
    else listOf(url to title)
    if (items.isNotEmpty()) Dl.enqueue(items, height, kbps)
}

@Composable
fun FormatDialog(url: String, title: String, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDone, containerColor = Color(0xFF111111),
        text = {
            FormatPicker(title, YtRepo.hasList(url), busy) { h, kbps, whole ->
                scope.launch { busy = true; startDownload(url, title, whole, h, kbps); onDone() }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onDone) { Text("Cancelar", color = Color.Gray) } }
    )
}

/** Se o app fechou por erro, mostra o motivo na próxima abertura (dá para copiar e me enviar). */
@Composable
fun CrashReport() {
    val ctx = LocalContext.current
    val f = remember { File(ctx.filesDir, "crash.txt") }
    var text by remember { mutableStateOf(if (f.exists()) f.readText().take(4000) else null) }
    text?.let { t ->
        AlertDialog(
            onDismissRequest = {}, containerColor = Color(0xFF111111), title = { Text("O app fechou por um erro") },
            text = { Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) { Text(t, fontSize = 10.sp, color = Color.LightGray) } },
            confirmButton = { TextButton({ ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("erro", t)) }) { Text("Copiar", color = Turq) } },
            dismissButton = { TextButton({ f.delete(); text = null }) { Text("Fechar", color = Color.Gray) } }
        )
    }
}

// ───────────────────────── Pesquisar ─────────────────────────
private val CATS = listOf(
    "🎵 Músicas livres" to "música sem direitos autorais",
    "📜 Creative Commons" to "creative commons",
    "🎬 Trilhas p/ vídeos" to "trilha sonora livre para vídeos",
    "🎙️ Podcasts" to "podcast",
    "📚 Aulas" to "aula tutorial",
    "🌿 Relaxamento" to "música relaxante sem copyright"
)
private val searchCache = mutableMapOf<String, List<VideoItem>>()

@Composable
fun SearchTab() {
    val ctx = LocalContext.current
    var link by remember { mutableStateOf("") }
    var clip by remember { mutableStateOf<String?>(null) }
    var linkUrl by remember { mutableStateOf<String?>(null) }
    var pick by remember { mutableStateOf<VideoItem?>(null) }
    var sel by remember { mutableIntStateOf(0) }
    var retry by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf(searchCache[CATS[0].second] ?: emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }

    // Detecta link do YouTube copiado ao abrir a aba / voltar pro app
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                val t = ctx.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
                clip = t?.takeIf { YtRepo.isYt(it) }?.let { YtRepo.extract(it) }
            }
        }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }

    // Carrega sozinho os vídeos da categoria escolhida
    LaunchedEffect(sel, retry) {
        val q = CATS[sel].second
        error = false
        val cached = searchCache[q]
        if (cached != null) { videos = cached; return@LaunchedEffect }
        loading = true; videos = emptyList()
        try {
            val r = YtRepo.search(q)
            searchCache[q] = r; videos = r
        } catch (e: CancellationException) { throw e
        } catch (e: Throwable) { error = true }
        loading = false
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 16.dp)) {
        OutlinedTextField(
            link, { link = it; if (YtRepo.isYt(it)) linkUrl = YtRepo.extract(it) }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Cole o link do YouTube") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { if (YtRepo.isYt(link)) linkUrl = YtRepo.extract(link) })
        )
        clip?.let { c ->
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth().clickable { linkUrl = c }, colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2B28))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Link copiado detectado", color = Turq)
                    Text(c, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                    Text("Toque para baixar", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CATS.size) { i ->
                val on = i == sel
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(if (on) Turq else Color(0xFF151515))
                        .clickable { sel = i }.padding(horizontal = 14.dp, vertical = 9.dp)
                ) { Text(CATS[i].first, color = if (on) Color.Black else Color.White) }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Turq)
        if (error) {
            Text("Não foi possível carregar agora.", color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
            TextButton({ searchCache.remove(CATS[sel].second); retry++ }) { Text("Tentar de novo", color = Turq) }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(videos) { v ->
                Row(Modifier.fillMaxWidth().clickable { pick = v }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(v.thumb)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${v.channel} • ${v.seconds / 60}:${"%02d".format(v.seconds % 60)}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    pick?.let { FormatDialog(it.url, it.title) { pick = null } }
    linkUrl?.let { FormatDialog(it, it) { linkUrl = null; link = "" } }
}

/** Miniatura carregada sem biblioteca externa (mantém o APK pequeno). */
@Composable
fun Thumb(url: String?) {
    val bmp by produceState<Bitmap?>(null, url) {
        value = url?.let { u -> withContext(Dispatchers.IO) { runCatching { URL(u).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull() } }
    }
    Box(Modifier.size(width = 110.dp, height = 62.dp).background(Color(0xFF111111))) {
        bmp?.let { androidx.compose.foundation.Image(it.asImageBitmap(), null, Modifier.fillMaxSize()) }
    }
}

// ───────────────────────── Biblioteca ─────────────────────────
@Composable
fun LibraryTab() {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf(emptyList<LFile>()) }
    var tick by remember { mutableIntStateOf(0) }
    val done = Dl.jobs.collectAsState().value.count { it.st == St.DONE }
    LaunchedEffect(tick, done) { files = withContext(Dispatchers.IO) { Library.list(ctx) } }

    var playing by remember { mutableStateOf<LFile?>(null) }
    var renaming by remember { mutableStateOf<LFile?>(null) }
    var deleting by remember { mutableStateOf<LFile?>(null) }
    var moving by remember { mutableStateOf<LFile?>(null) }
    val mover = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { dest ->
        val f = moving; moving = null
        if (dest != null && f != null) { Library.moveTo(ctx, f, dest); tick++ }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Pasta: Download/Lindoso Download", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        if (files.isEmpty()) Text("Nada baixado ainda.", Modifier.padding(top = 24.dp), color = Color.Gray)
        LazyColumn {
            items(files, key = { it.uri.toString() }) { f ->
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("%.1f MB".format(f.size / 1_048_576.0), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({ playing = f }) { Text("Abrir", color = Turq) }
                        TextButton({ renaming = f }) { Text("Renomear", color = Turq) }
                        TextButton({ moving = f; mover.launch(f.name) }) { Text("Mover", color = Turq) }
                        TextButton({ deleting = f }) { Text("Excluir", color = Color(0xFFFF6B6B)) }
                    }
                }
            }
        }
    }

    playing?.let { f ->
        Dialog({ playing = null }) {
            AndroidView({ c ->
                VideoView(c).apply {
                    setMediaController(MediaController(c).also { it.setAnchorView(this) })
                    setVideoURI(f.uri); setOnPreparedListener { start() }
                }
            }, Modifier.fillMaxWidth().height(260.dp).background(Color.Black))
        }
    }
    renaming?.let { f ->
        var name by remember { mutableStateOf(f.name) }
        AlertDialog(
            onDismissRequest = { renaming = null }, containerColor = Color(0xFF111111), title = { Text("Renomear") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton({ Library.rename(ctx, f, name); renaming = null; tick++ }) { Text("Salvar", color = Turq) } },
            dismissButton = { TextButton({ renaming = null }) { Text("Cancelar", color = Color.Gray) } }
        )
    }
    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null }, containerColor = Color(0xFF111111), title = { Text("Excluir arquivo?") },
            text = { Text(f.name) },
            confirmButton = { TextButton({ Library.delete(ctx, f); deleting = null; tick++ }) { Text("Excluir", color = Color(0xFFFF6B6B)) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancelar", color = Color.Gray) } }
        )
    }
}
