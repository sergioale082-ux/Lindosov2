package com.lindoso.download

import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.net.HttpURLConnection
import java.net.URL

const val UA = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

/** Downloader mínimo (HttpURLConnection) exigido pelo NewPipeExtractor — sem OkHttp para manter o APK leve. */
class HttpDownloader : Downloader() {
    override fun execute(request: Request): Response {
        val c = URL(request.url()).openConnection() as HttpURLConnection
        c.requestMethod = request.httpMethod()
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", UA)
        request.headers().forEach { (k, v) -> c.setRequestProperty(k, v.joinToString(", ")) }
        request.dataToSend()?.let { c.doOutput = true; c.outputStream.use { o -> o.write(it) } }

        val code = c.responseCode
        if (code == 429) throw ReCaptchaException("reCaptcha", request.url())
        val body = (if (code in 200..399) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        return Response(code, c.responseMessage, c.headerFields.filterKeys { it != null }, body, c.url.toString())
    }
}
