package com.lindoso.download

import android.app.Application
import android.util.Log
import java.io.File

class LindosoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(e)) }
            old?.uncaughtException(t, e)
        }
        YtRepo.init()
        Dl.start(this)
    }
}
