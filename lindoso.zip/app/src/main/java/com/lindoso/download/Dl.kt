package com.lindoso.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

enum class St { QUEUED, RUNNING, PAUSED, WAITING, DONE, ERROR }

data class DlState(
    val id: Long, val title: String, val url: String, val height: Int?,   // height == null -> só áudio
    val kbps: Int = 0,                                                    // só áudio: 0 = M4A original, senão converte para MP3 nesse bitrate
    val progress: Float = 0f, val st: St = St.QUEUED, val msg: String = ""
)

private class PauseEx : Exception()
private class Picked(val urls: List<String>, val ext: String, val mime: String)

/** Fila de downloads: um por vez, pausa/retomada por HTTP Range, retry automático quando a internet cai. */
object Dl {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val paused = ConcurrentHashMap.newKeySet<Long>()
    private val queue = Channel<Long>(Channel.UNLIMITED)
    private var seq = System.currentTimeMillis()
    private lateinit var app: Context

    val jobs = MutableStateFlow<List<DlState>>(emptyList())
    val panel = MutableStateFlow(true)      // aba de downloads visível na tela Início
    fun clearFinished() = jobs.update { l -> l.filter { it.st != St.DONE && it.st != St.ERROR } }

    fun start(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        scope.launch { for (id in queue) runJob(id) }
    }

    fun enqueue(items: List<Pair<String, String>>, height: Int?, kbps: Int = 0) {
        val new = items.map { (u, t) -> DlState(++seq, t, u, height, kbps) }
        jobs.update { it + new }
        panel.value = true
        new.forEach { queue.trySend(it.id) }
        runCatching { ContextCompat.startForegroundService(app, Intent(app, DlService::class.java)) }
    }

    fun pause(id: Long) { paused += id }
    fun resume(id: Long) {
        paused -= id
        panel.value = true
        upd(id) { it.copy(st = St.QUEUED) }
        queue.trySend(id)
        runCatching { ContextCompat.startForegroundService(app, Intent(app, DlService::class.java)) }
    }

    private fun upd(id: Long, f: (DlState) -> DlState) = jobs.update { l -> l.map { if (it.id == id) f(it) else it } }

    private fun h(s: VideoStream) = s.resolution.takeWhile { it.isDigit() }.toIntOrNull() ?: 0

    private fun pick(info: StreamInfo, height: Int?): Picked {
        val a = info.audioStreams.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
        if (height == null) return Picked(listOf((a ?: error("sem áudio disponível")).content), "m4a", "audio/mp4")
        val muxed = info.videoStreams.filter { it.format == MediaFormat.MPEG_4 && h(it) <= height }.maxByOrNull { h(it) }
        val vo = info.videoOnlyStreams.filter { it.format == MediaFormat.MPEG_4 && h(it) <= height }.maxByOrNull { h(it) }
        return when {
            vo != null && a != null && h(vo) > (muxed?.let { h(it) } ?: 0) -> Picked(listOf(vo.content, a.content), "mp4", "video/mp4")
            muxed != null -> Picked(listOf(muxed.content), "mp4", "video/mp4")
            else -> error("formato indisponível para este vídeo")
        }
    }

    private suspend fun runJob(id: Long) {
        val s = jobs.value.firstOrNull { it.id == id } ?: return
        if (id in paused) { upd(id) { it.copy(st = St.PAUSED) }; return }
        upd(id) { it.copy(st = St.RUNNING, msg = "") }
        var tries = 0
        while (true) {
            try {
                val info = StreamInfo.getInfo(YtRepo.videoUrl(s.url))
                upd(id) { it.copy(title = info.name) }
                val p = pick(info, s.height)
                val dir = File(app.cacheDir, "dl").also { it.mkdirs() }
                val parts = p.urls.indices.map { File(dir, "$id-$it.part") }
                p.urls.forEachIndexed { i, u ->
                    fetch(id, u, parts[i]) { fr -> upd(id) { it.copy(progress = (i + fr) / p.urls.size * (if (s.kbps > 0) 0.9f else 1f), st = St.RUNNING, msg = "") } }
                }
                val safe = info.name.replace(Regex("""[\\/:*?"<>|]"""), "_").take(80)
                val out: File
                if (s.height == null && s.kbps > 0) {                 // MP3
                    out = File(dir, "$id.mp3")
                    upd(id) { it.copy(msg = "Convertendo para MP3…") }
                    Mp3.encode(parts[0], out, s.kbps) { fr -> upd(id) { it.copy(progress = 0.9f + 0.1f * fr) } }
                    Library.save(app, out, "$safe.mp3", "audio/mpeg")
                } else {
                    out = if (parts.size == 2) File(dir, "$id.mp4").also { Muxer.mux(parts[0], parts[1], it) } else parts[0]
                    Library.save(app, out, "$safe.${p.ext}", p.mime)
                }
                parts.forEach { it.delete() }; out.delete()
                upd(id) { it.copy(progress = 1f, st = St.DONE) }
                return
            } catch (e: PauseEx) {
                upd(id) { it.copy(st = St.PAUSED) }; return
            } catch (e: IOException) {                       // internet caiu: espera e continua de onde parou
                if (++tries > 30) { upd(id) { it.copy(st = St.ERROR, msg = "Sem conexão") }; return }
                upd(id) { it.copy(st = St.WAITING, msg = "Aguardando internet…") }
                delay(5000)
                if (id in paused) { upd(id) { it.copy(st = St.PAUSED) }; return }
            } catch (e: Throwable) {
                upd(id) { it.copy(st = St.ERROR, msg = "${e.javaClass.simpleName}: ${e.message}") }; return
            }
        }
    }

    /** Baixa em blocos de 5 MB com Range (o YouTube limita a velocidade de requisições sem Range) e retoma pelo tamanho do .part. */
    private fun fetch(id: Long, url: String, f: File, prog: (Float) -> Unit) {
        val chunk = 5_000_000L
        var have = f.length()
        while (true) {
            if (id in paused) throw PauseEx()
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Range", "bytes=$have-${have + chunk - 1}")
            val code = c.responseCode
            if (code == 416) { c.disconnect(); return }                 // já estava completo
            if (code != 206 && code != 200) { c.disconnect(); throw IOException("HTTP $code") }
            val total = c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: c.contentLengthLong
            if (code == 200 && have > 0) { f.delete(); have = 0 }       // servidor ignorou o Range
            FileOutputStream(f, have > 0).use { o ->
                c.inputStream.use { i ->
                    val b = ByteArray(32 * 1024)
                    while (true) {
                        val n = i.read(b); if (n < 0) break
                        o.write(b, 0, n); have += n
                        prog(if (total > 0) (have.toFloat() / total).coerceIn(0f, 1f) else 0f)
                        if (id in paused) throw PauseEx()
                    }
                }
            }
            c.disconnect()
            if (total <= 0 || have >= total) return
        }
    }
}
