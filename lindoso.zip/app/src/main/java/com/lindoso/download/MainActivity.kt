package com.lindoso.download

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            LindosoTheme {
                CopyrightNotice(onExit = { finish() })
                CrashReport()
                App()
            }
        }
    }

    // Ao minimizar, sobe o serviço que mantém o áudio/vídeo do YouTube tocando
    override fun onPause() {
        super.onPause()
        Web.view?.let { it.onResume(); it.resumeTimers() }
        runCatching { startForegroundService(Intent(this, PlayService::class.java)) }
    }

    override fun onStop() {
        super.onStop()
        Web.view?.let { it.onResume(); it.resumeTimers() }
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, PlayService::class.java))
    }
}
