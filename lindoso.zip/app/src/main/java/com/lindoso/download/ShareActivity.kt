package com.lindoso.download

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Aparece no menu Compartilhar do YouTube: escolhe o formato e baixa, sem abrir o app. */
class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        if (!YtRepo.isYt(text)) { toast("Link do YouTube não encontrado"); finish(); return }
        if (!getSharedPreferences("p", MODE_PRIVATE).getBoolean("ok", false)) {
            toast("Abra o Lindoso Download uma vez para aceitar o aviso de direitos autorais"); finish(); return
        }
        val url = YtRepo.extract(text)
        setContent {
            LindosoTheme {
                val scope = rememberCoroutineScope()
                var busy by remember { mutableStateOf(false) }
                Box(
                    Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish() },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)).background(Color(0xFF151515))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                            .padding(20.dp)
                    ) {
                        FormatPicker(url, YtRepo.hasList(url), busy) { h, whole ->
                            scope.launch {
                                busy = true
                                startDownload(url, url, whole, h)
                                toast("Baixando… acompanhe em Lindoso Download")
                                finish()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
