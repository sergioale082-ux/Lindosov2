package com.lindoso.download

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder

/** Converte o áudio AAC/M4A baixado em MP3: decodifica com MediaCodec (nativo) e codifica com LAME (TAndroidLame). */
object Mp3 {
    fun encode(src: File, out: File, kbps: Int, onProgress: (Float) -> Unit) {
        val ex = MediaExtractor().apply { setDataSource(src.path) }
        var dec: MediaCodec? = null
        var lame: LameRef? = null
        val os = FileOutputStream(out).buffered(256 * 1024)
        try {
            val track = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec.configure(fmt, null, null, 0)
            dec.start()

            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false

            fun ensureLame(): LameRef = lame ?: LameRef(rate, channels, kbps).also { lame = it }

            while (!outDone) {
                if (!inDone) {
                    val i = dec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = dec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val nf = dec.outputFormat
                        if (lame == null) {                      // só ajusta antes de começar a codificar
                            if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                    }
                    o >= 0 -> {
                        if (info.size > 0) {
                            val ob = dec.getOutputBuffer(o)!!
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            val pcm = ShortArray(info.size / 2)
                            ob.order(ByteOrder.nativeOrder()).asShortBuffer().get(pcm)
                            val frames = pcm.size / channels
                            val mp3 = ByteArray(7200 + (frames * 1.25).toInt())
                            val l = ensureLame()
                            val n = if (channels == 1) l.mono(pcm, frames, mp3) else l.interleaved(pcm, frames, mp3)
                            if (n > 0) os.write(mp3, 0, n)
                        }
                        dec.releaseOutputBuffer(o, false)
                        if (durUs > 0) onProgress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                }
            }
            lame?.let { l ->
                val tail = ByteArray(7200)
                val n = l.flush(tail)
                if (n > 0) os.write(tail, 0, n)
            }
        } finally {
            runCatching { os.close() }
            runCatching { dec?.stop() }; runCatching { dec?.release() }
            runCatching { ex.release() }
            lame?.close()
        }
    }
}

/** Usa a biblioteca TAndroidLame por reflexão, para não depender dos nomes exatos dos métodos de cada versão. */
private class LameRef(rate: Int, channels: Int, kbps: Int) {
    private val intT = Int::class.javaPrimitiveType!!
    private val cls = Class.forName("com.naman14.androidlame.AndroidLame")
    private val obj: Any

    init {
        val bcls = Class.forName("com.naman14.androidlame.LameBuilder")
        var b: Any = bcls.getConstructor().newInstance()
        fun set(names: List<String>, v: Int) {
            val m = bcls.methods.firstOrNull { it.name in names && it.parameterTypes.size == 1 && it.parameterTypes[0] == intT } ?: return
            val r = m.invoke(b, v)
            if (r != null && bcls.isInstance(r)) b = r
        }
        set(listOf("setInSampleRate"), rate)
        set(listOf("setOutChannels", "setOutChannel", "setNumChannels"), channels)
        set(listOf("setOutBitrate", "setBitrate"), kbps)
        set(listOf("setOutSampleRate"), rate)
        set(listOf("setQuality"), 2)
        obj = bcls.getMethod("build").invoke(b)!!
    }

    private val mInter = cls.methods.first { it.name == "encodeBufferInterleaved" }
    private val mEnc = cls.methods.first { it.name == "encode" && it.parameterTypes.size == 4 }
    private val mFlush = cls.methods.firstOrNull { (it.name == "flush" || it.name == "lameFlush") && it.parameterTypes.size == 1 }
    private val mClose = cls.methods.firstOrNull { it.name == "close" && it.parameterTypes.isEmpty() }

    fun interleaved(pcm: ShortArray, frames: Int, out: ByteArray): Int = mInter.invoke(obj, pcm, frames, out) as Int
    fun mono(pcm: ShortArray, frames: Int, out: ByteArray): Int = mEnc.invoke(obj, pcm, pcm, frames, out) as Int
    fun flush(out: ByteArray): Int = (mFlush?.invoke(obj, out) as? Int) ?: 0
    fun close() { runCatching { mClose?.invoke(obj) } }
}
