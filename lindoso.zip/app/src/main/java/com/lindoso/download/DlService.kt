package com.lindoso.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

/** Serviço em primeiro plano: mantém o download vivo com o app minimizado. */
class DlService : Service() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var watcher: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("dl", "Downloads", NotificationManager.IMPORTANCE_LOW))
        runCatching { startForeground(1, build("Iniciando…", 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) }
        if (watcher == null) watcher = scope.launch {
            Dl.jobs.collect { l ->
                val active = l.filter { it.st == St.RUNNING || it.st == St.QUEUED || it.st == St.WAITING }
                if (active.isEmpty()) { stopSelf(); return@collect }
                val cur = active.first()
                nm.notify(1, build("${active.size} em andamento • ${cur.title}", (cur.progress * 100).toInt()))
            }
        }
        return START_NOT_STICKY
    }

    private fun build(text: String, pct: Int): Notification =
        Notification.Builder(this, "dl")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Lindoso Download")
            .setContentText(text)
            .setProgress(100, pct.coerceIn(0, 100), false)
            .setOngoing(true)
            .build()

    override fun onDestroy() { scope.cancel(); watcher = null; super.onDestroy() }
}
