package com.lindoso.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager

/** Serviço em primeiro plano: mantém o YouTube tocando com o app minimizado ou a tela apagada. */
class PlayService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("play", "Reprodução", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "play")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lindoso Download")
            .setContentText("Tocando em segundo plano")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        runCatching { startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) }
        if (wake == null) wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lindoso:play").apply { acquire() }
        return START_NOT_STICKY
    }

    override fun onDestroy() { runCatching { wake?.release() }; wake = null; super.onDestroy() }
}
